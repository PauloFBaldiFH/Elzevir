The following table lists the data sets we have collected for testing purposes.

^ File name         ^ Format    ^ Encoding ^ Source system ^ Description            ^
| auth-1066.mrc     | MARC21    | UTF8     | Aleph         | Dutch authority records from IISH (missing 0 in leader 22) |
| auth-subset100.mrc| MARC21    | UTF8     | Aleph         | Dutch authority records from IISH (missing 0 in leader 22) |
| badisbns.xml      | MARC21XML | UTF8     |               | 10 records with known bad ISBNs |
| FSL.marc          | MARC21    | UTF8     | Aleph         | Armenian and Cyrillic scripts, collected from the Fundamental Science Library in Yerevan, Armenia |
| hebrew.marc       | MARC21    | MARC8    | III           | Hebrew scripts, 25 records |
| lul_fre_100.marc  | MARC21    | MARC8    | Unicorn GL3.1 | 100 records, French, pre-1923  |
| lul_fre_500.marc  | MARC21    | MARC8    | Unicorn GL3.1 | 500 records, French, pre-1923  |
| jazz_1k.marc      | MARC21    | MARC8    | Unicorn GL3.1 | 1000 records  |
| map_data.marc     | MARC21    | UTF8     | Voyager (LoC) | 3 records with some geospatial metadata  |
| music_5k.marc     | MARC21    | MARC8    | Unicorn GL3.1 | 5000 records  |
| nepali.marc       | MARC21    | UTF8     |               | Nepali scripts, 98 records, dual 245 and 100 fields (one for Nepali, one for phoneticization |
| oss.marc          | MARC21    | MARC8    | Unicorn GL3.1 |   |
| serials_marc21.xml| MARC21XML | UTF8     |               | A small set of MARC21 bibliographic records |
| serials_mfhd.xml  | MARC21XML | UTF8     |               | MFHD records that map to the serials_marc21.xml records |


=====How to load the test MFHD records=====

  - First load the MARC21 records:
    - perl ../../src/extras/import/marc2bre.pl --marctype XML --start 1 --idfield 901 --idsubfield a serials_marc21.xml | perl ../../src/extras/import/pg_loader.pl -or bre -or mrd -or mfr -or mtfe -or mafe -or msfe -or mkfe -or msefe -a mrd -a mfr -a mtfe -a mafe -a msfe -a mkfe -a msefe | psql -U evergreen -h localhost

  - Then generate the metarecord map:
    - pgsql -f ../../src/extras/import/quick_metarecord_map.sql

  - Then process and load the MFHD records - ingest is not used. Adjust the
    contents of serials_lib.map to match your library-to-actor.org_unit.id
    mappings:
    - perl ../../src/extras/import/marc2sre.pl --marctype XML --libmap serials_lib.map --password open-ils serials_mfhd.xml | perl ../../src/extras/import/pg_loader.pl -or sre > mfhd21.sql
    - psql -f mfhd21.sql

